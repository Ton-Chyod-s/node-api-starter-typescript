import 'dotenv/config';
import { defineConfig, env as prismaEnv } from 'prisma/config';

export default defineConfig({
  schema: 'prisma',
  migrations: {
    path: 'prisma/migrations',
    seed: 'tsx prisma/seed.ts',
  },
  datasource: {
    url: prismaEnv('DATABASE_URL'),
  },
});
